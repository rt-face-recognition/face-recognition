// Import the messaging module
import * as messaging from "messaging";
import { vibration } from "haptics";
import document from "document";
import { display } from "display";

display.autoOff = true;
display.on = true;


// Listen for the onopen event
messaging.peerSocket.onopen = function() {
  // Fetch faces when the connection opens
	//fetchPeople();
	console.log("Opening connection... I think");
}


// Listen for messages from the companion
messaging.peerSocket.onmessage = function(evt) {
	if (evt) {
		console.log("received something!");
		let demotext = document.getElementById("demotext");
		demotext.text = "Connection Near By: ";
    display.on = true;
    vibration.start("nudge-max");
    //const number = evt.faces.length;
		//console.log(evt.faces[number-1].name);
    console.log(JSON.stringify(evt.data))
    
    var myText  = document.getElementById("myText");
    var myImage = document.getElementById("myImage");

    myText.text= JSON.stringify(evt.data);
     
	}
}


// Request face data from the companion
function fetchPeople() {
  if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
    // Send a command to the companion
  	messaging.peerSocket.send({command: "face-recognition"});
  }
}


// Listen for the onerror event
messaging.peerSocket.onerror = function(err) {
  // Handle any errors
  console.log("Connection error: " + err.code + " - " + err.message);
}


// Fetch the weather every 10 seconds
setInterval(fetchPeople, 10 * 1000);
