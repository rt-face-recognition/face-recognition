// Import the messaging module
import * as messaging from "messaging";

var ENDPOINT = "https://facial-recognition-hack.herokuapp.com/facial/api/v1.0/faces/get";
var prevGuy = ""
var name = ""

function queryFaceData() {
  fetch(ENDPOINT)
  .then(function (response) {
      //console.log(response)
      response.json()
      .then(function(data) {
        //console.log(typeof data);
        // console.log('Array below: ')
        // console.log(data.faces);
        // console.log('Length: ' + data.faces.length);
        const number = data.faces.length;
        // console.log('Sending this: ' + data.faces[number-1].name)
        
        name = data.faces[number-1].name.toString()
        if (name != prevGuy) {
          sendToFitbit(data.faces[number-1].name.toString());
          prevGuy = name
        }
        
        //sendToFitbit(data.faces[number-1].time);
        //var dict = data["faces"];
        //console.log(dict);
        // for (var item in dict) {
        //   console.log(item)
        //   // console.log(typeof item);
        //   // var temp = {
        //   //   "name": item["name"],
        //   //   "time": item["time"]
        //   // }
        //   // console.log(temp["name"]);
        //   // console.log(temp["time"]);
        //   // Send the weather data to the device
        //   sendToFitbit(item);
        // }
      });
  })
  .catch(function (err) {
    console.log("Error fetching weather: " + err);
  });


  // sendToFitbit(ENDPOINT 
}


// Send the weather data to the device
function sendToFitbit(data) {
  if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
    // In seconds
    var DELAY = 2*60;
    var current_time = Math.round((new Date()).getTime() / 1000);

    // Send a command to the device if it's over the delay time
    if (5>3) {
      messaging.peerSocket.send(data);
      // console.log("sending")
      // console.log(data)
    } else {
		console.log("Data found, but not sent due to time limits");
	         }
  }
    else {
    console.log("Error: Connection is not open");
  }
}


// Listen for messages from the device
messaging.peerSocket.onmessage = function(evt) {
  if (evt.data) {
	  if (evt.data.command == "face-recognition") {
    	// The device requested face data
    	queryFaceData();
    } else {
      console.log("Error: data was received on the companion, but incorrect command");
    }
  }
}



// Listen for the onerror event
messaging.peerSocket.onerror = function(err) {
  // Handle any errors
  console.log("Connection error: " + err.code + " - " + err.message);
}
